-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 12 月 30 日 05:38
-- 服务器版本: 5.5.24-log
-- PHP 版本: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `travel`
--

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `CategoryId` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `StoreId` int(11) NOT NULL,
  PRIMARY KEY (`CategoryId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`CategoryId`, `CategoryName`, `StoreId`) VALUES
(1, '美东', 1),
(2, '美西', 1),
(3, '中国', 1),
(4, '加拿大', 1);

-- --------------------------------------------------------

--
-- 表的结构 `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `RouteId` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryId` int(11) NOT NULL COMMENT 'FK',
  `Title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CoverImage` varchar(1055) COLLATE utf8_unicode_ci NOT NULL,
  `Code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Duration` int(11) NOT NULL,
  `OriginPrice` varchar(25) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Display only',
  `Price` decimal(5,2) NOT NULL,
  `ChildrenPrice` decimal(5,2) NOT NULL,
  `Content` text COLLATE utf8_unicode_ci NOT NULL,
  `StoreId` int(11) NOT NULL,
  PRIMARY KEY (`RouteId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `route`
--

INSERT INTO `route` (`RouteId`, `CategoryId`, `Title`, `CoverImage`, `Code`, `Duration`, `OriginPrice`, `Price`, `ChildrenPrice`, `Content`, `StoreId`) VALUES
(1, 1, '(3天)美東名校：哈佛、麻省、議會大廈、尼亞加拉、康寧玻璃中心 ', 'http://images.tours4fun.com/images/2326_boston-skyline_1.jpg', '81-2265', 3, '255', '212.50', '190.50', '早上前往康寧玻璃中心，不僅可以欣賞30000多件曆年的玻璃制品，還能親眼目睹整個制作過程，看高溫的玻璃水怎麼在能工巧匠的手裡變成精美的藝術品。末了，別忘挑一件中意的留作紀念。隨後前往氣勢磅礴的尼亞加拉瀑布，有馬蹄瀑布（馬蹄Falls），美國瀑布和新娘面紗瀑布組成。值得一提的是夜晚的瀑布分外迷人，記得定要拿起相機“哢嚓哢嚓…”將美景定格，帶回家供家人，朋友們欣賞。', 1),
(2, 1, '(3天)美東名校：哈佛、麻省、議會大廈、尼亞加拉、康寧玻璃中心 Copy 2 ', 'http://images.tours4fun.com/images/2326_boston-skyline_1.jpg', '81-2265', 3, '255', '212.50', '190.50', '早上前往康寧玻璃中心，不僅可以欣賞30000多件曆年的玻璃制品，還能親眼目睹整個制作過程，看高溫的玻璃水怎麼在能工巧匠的手裡變成精美的藝術品。末了，別忘挑一件中意的留作紀念。隨後前往氣勢磅礴的尼亞加拉瀑布，有馬蹄瀑布（馬蹄Falls），美國瀑布和新娘面紗瀑布組成。值得一提的是夜晚的瀑布分外迷人，記得定要拿起相機“哢嚓哢嚓…”將美景定格，帶回家供家人，朋友們欣賞。', 1),
(3, 2, '(3天)美東名校：哈佛、麻省、議會大廈、尼亞加拉、康寧玻璃中心 COPY 3 ', 'http://images.tours4fun.com/images/2326_boston-skyline_1.jpg', '81-2265', 3, '255', '212.50', '190.50', '早上前往康寧玻璃中心，不僅可以欣賞30000多件曆年的玻璃制品，還能親眼目睹整個制作過程，看高溫的玻璃水怎麼在能工巧匠的手裡變成精美的藝術品。末了，別忘挑一件中意的留作紀念。隨後前往氣勢磅礴的尼亞加拉瀑布，有馬蹄瀑布（馬蹄Falls），美國瀑布和新娘面紗瀑布組成。值得一提的是夜晚的瀑布分外迷人，記得定要拿起相機“哢嚓哢嚓…”將美景定格，帶回家供家人，朋友們欣賞。', 1),
(4, 1, '奧巴馬總統度假勝地風情遊：瑪莎葡萄島+普利茅斯(5天) ', 'http://images.tours4fun.com/images/201407161405493398_53c62096d8e2e_watermark_800_800.jpg', '12345-67', 5, '999', '599.00', '499.00', '如果您在出團日期之前的任何一天到達紐約JFK和LGA機場，我們每個預定單均提供一次9:00am-10:00pm的免費接機服務，並可將您送往中國城(Chinatown)或者法拉盛(Flushing)地區(中國城的地址是：87 BOWERY, N.Y10002；法拉盛地址是：39TH AVE FLUSHING, N.Y11354)；\r\n-如果您提前跟我們預定了以“33-”開頭的法拉盛(FLU)、紐約肯尼迪機場(JFK)、紐約拉瓜迪亞機場(LGA)、新澤西(NJ)地區的酒店，我們可為您提供JFK, LGA, EWR機場的接機，並將您送到酒店。\r\n-請注意：您只能選擇出團日期當天或出團日期之前某一天的一次免費接機，若您需要多次接機或免費接機時間之外的接機服務，請聯系我們取得報價。', 1),
(5, 2, '4日伍德伯裡直銷工廠(Woodbury Outlets)超級購物之旅 ', 'http://images.tours4fun.com/images/2326_boston-skyline_1.jpg', 'csdf-sdqw', 4, '110', '100.00', '90.00', '現代的Outlet，已成為一種時尚，品牌，質量及物美價廉的代名詞。人們，尤其是女仕們對此津津樂道，趨之若鶩，且樂此不疲。近年來，位於美國紐約上州的Woodbury Common Premium Outlets成為人們追求時尚，品牌，物美價廉的最佳選擇。這裡集中了世界各地時尚品牌220多家，不但有流行的二線品牌，更有Burberry, Coach, Dolce & Gabbana, Fendi, Gap Outlet, Giorgio Armani, Gucci, J.Crew, Channel, Jimmy Choo, Lacoste, Neiman Marcus Last Call, Polo Ralph Lauren, Prada, Saks Fifth Avenue Off 5th, Tod''s, Tory Burch, Zegna 等一線高端品牌在此聚集。 Woodbury Outlets之大，品牌繁多，沒有人能在一天時間內逛完，每每商鋪打烊時，遊客們仍然遊興未盡，留連忘返。', 2);

-- --------------------------------------------------------

--
-- 表的结构 `route_departure`
--

CREATE TABLE IF NOT EXISTS `route_departure` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RouteId` int(11) NOT NULL,
  `City` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `route_departure`
--

INSERT INTO `route_departure` (`Id`, `RouteId`, `City`) VALUES
(1, 1, '纽约'),
(2, 1, '波士顿'),
(3, 2, '纽约'),
(4, 3, '华盛顿'),
(5, 4, 'Hempster'),
(6, 5, '华盛顿');

-- --------------------------------------------------------

--
-- 表的结构 `route_destination`
--

CREATE TABLE IF NOT EXISTS `route_destination` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RouteId` int(11) NOT NULL,
  `City` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `route_destination`
--

INSERT INTO `route_destination` (`Id`, `RouteId`, `City`) VALUES
(1, 1, '非城'),
(2, 1, '多论多'),
(3, 2, '温哥华'),
(4, 3, '广周'),
(5, 1, '香港'),
(6, 4, 'Brooklyn'),
(7, 5, '华盛顿');

-- --------------------------------------------------------

--
-- 表的结构 `route_room`
--

CREATE TABLE IF NOT EXISTS `route_room` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RouteId` int(11) NOT NULL,
  `RoomNumber` int(11) NOT NULL,
  `Price` decimal(5,2) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `route_room`
--

INSERT INTO `route_room` (`Id`, `RouteId`, `RoomNumber`, `Price`) VALUES
(1, 1, 1, '175.00'),
(2, 1, 2, '150.00'),
(3, 1, 3, '150.00'),
(4, 1, 4, '150.00'),
(5, 2, 1, '250.00'),
(6, 2, 2, '200.00'),
(7, 2, 3, '200.00'),
(8, 2, 4, '200.00'),
(9, 1, 5, '175.00'),
(10, 1, 6, '125.00'),
(11, 2, 5, '250.00'),
(12, 2, 6, '150.00');

-- --------------------------------------------------------

--
-- 表的结构 `route_schedule`
--

CREATE TABLE IF NOT EXISTS `route_schedule` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `RouteId` int(11) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `PriceAdjust` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `route_schedule`
--

INSERT INTO `route_schedule` (`Id`, `RouteId`, `StartDate`, `EndDate`, `PriceAdjust`) VALUES
(1, 1, '2014-12-01', '2014-12-15', '0.00'),
(2, 1, '2014-12-25', NULL, '0'),
(4, 2, '2014-11-01', NULL, '+100'),
(5, 3, '2015-01-01', '9999-00-00', '299'),
(6, 1, '2015-02-01', NULL, '0'),
(7, 4, '0000-00-00', '2015-02-28', '0'),
(8, 1, '2015-02-03', NULL, '0');

-- --------------------------------------------------------

--
-- 表的结构 `route_schedule_day`
--

CREATE TABLE IF NOT EXISTS `route_schedule_day` (
  `RouteId` int(11) NOT NULL AUTO_INCREMENT,
  `Days` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RouteId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `route_schedule_day`
--

INSERT INTO `route_schedule_day` (`RouteId`, `Days`) VALUES
(1, '2,5'),
(2, '1,2,3'),
(3, '2,4,6');

-- --------------------------------------------------------

--
-- 表的结构 `store`
--

CREATE TABLE IF NOT EXISTS `store` (
  `StoreId` int(11) NOT NULL AUTO_INCREMENT,
  `Domain` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`StoreId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `store`
--

INSERT INTO `store` (`StoreId`, `Domain`, `Name`) VALUES
(1, 'www.nycwebmasters.com', 'Usa4Fun'),
(2, 'winson.nycwebmasters.com', 'WinSon');

-- --------------------------------------------------------

--
-- 表的结构 `store_category`
--

CREATE TABLE IF NOT EXISTS `store_category` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `StoreId` int(11) NOT NULL,
  `CategoryId` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `store_category`
--

INSERT INTO `store_category` (`Id`, `StoreId`, `CategoryId`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 2, 1),
(6, 2, 2);

-- --------------------------------------------------------

--
-- 表的结构 `store_route`
--

CREATE TABLE IF NOT EXISTS `store_route` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `StoreId` int(11) NOT NULL,
  `OriginRouteId` int(11) NOT NULL,
  `RouteId` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `store_route`
--

INSERT INTO `store_route` (`Id`, `StoreId`, `OriginRouteId`, `RouteId`) VALUES
(1, 1, 1, 1),
(2, 1, 2, 2),
(3, 1, 3, 3),
(4, 1, 4, 4),
(5, 2, 1, 1),
(6, 2, 4, 4),
(7, 2, 2, 5);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
